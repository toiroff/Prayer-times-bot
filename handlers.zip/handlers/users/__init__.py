from . import help
from . import start
from . import vaqtlar
from . import Toshkent
from . import namoz
from . import echo